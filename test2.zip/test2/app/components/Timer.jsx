var React = require('react');

var Timer = React.createClass({
  render: function () {
    return <p>Timer.jsx</p>;
  }
});

module.exports = Timer;
